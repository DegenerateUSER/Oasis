OASIS LATEX SUBMISSION SOURCE

All editable manuscript, cover-letter/reviewer-response, combined-revision and repository-supplement sources plus required tables, references, class, style and original branding assets.

Entry points:
1. manuscript.tex -- article only
2. reviewer-letter.tex -- standalone cover letter and all14 responses; build manuscript first to create manuscript.aux for page references
3. 1352_revised_version.tex -- combined manuscript and responses
4. repository-supplement.tex -- complete repository table

Keep every supplied file together. Compile with Tectonic using the order above. The full evidence archive is supplied separately as Oasis-editable-LaTeX-and-evidence.zip. This source-only ZIP does not include native experiment data or a certified similarity report.
